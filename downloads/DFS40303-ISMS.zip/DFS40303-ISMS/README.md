# Dashboard DFS40303 ISMS

This folder contains the complete latest dashboard, including the Notes menu with Procedures and Policies submenus.

## Open the dashboard

Open index.html in your browser. For a consistent browser-storage origin, you can serve this folder locally:

```sh
python3 -m http.server 8000
```

Then open http://localhost:8000. No installation or build step is needed. All HTML, CSS and JavaScript are contained in index.html.

## Important

Initial student records are fictional Demo Data. Edits are stored in the current browser and device only. Your existing live-dashboard edits are not included in this download; export student records as CSV from the live dashboard to keep a copy. Document links do not upload files.

## Contents

- index.html: complete interactive dashboard, lesson planner, competency tracker, assessment rubric, follow-up and study notes.
- README.md: these instructions.
